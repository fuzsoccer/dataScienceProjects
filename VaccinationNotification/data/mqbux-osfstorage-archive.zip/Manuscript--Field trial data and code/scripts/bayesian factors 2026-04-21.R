
####################################
# https://bayesplay.colling.net.nz/
####################################
# Colling LJ (2023). bayesplay: The Bayes Factor Playground. R package version 0.9.3, https://github.com/bayesplay/bayesplay.

@Manual{,
  title = {bayesplay: The Bayes Factor Playground},
  author = {Lincoln John Colling},
  year = {2023},
  note = {R package version 0.9.3},
  url = {https://github.com/bayesplay/bayesplay},
}

# if the bayesplay package is not installed then install it with
#install.packages("bayesplay")
# load the bayesplay package
library(bayesplay)

# To replicate Bayes Factors reported in the Manuscript follow these steps:
#### STEP 1: GENERATE A data_model
#### STEP 2: SKIP TO THE GENERATE BF SECTION AT THE BOTTOM AND RUN 


#### STEP 1: GENERATE A data_model

# Medial Study 1: algorithm vs. medical records
data_model <- likelihood(family = "normal", mean = 0.003, sd = .003/.366)
# Medial Study 1: high risk vs. medical records
data_model <- likelihood(family = "normal", mean = 0.004, sd = .004/.505)
# Medial Study 1: high risk vs. algorithm
data_model <- likelihood(family = "normal", mean = 0.001, sd = .001/.140)
# Medial Study 2: high risk vs. medical records/reasons
data_model <- likelihood(family = "normal", mean = 0.005, sd = .005/.670)
# Medial Study 2: high risk vs. algorithm/reasons
data_model <- likelihood(family = "normal", mean = 0.010, sd = .010/1.362)
# Medial Study 2: medical records/reasons vs. algorithm/reasons
data_model <- likelihood(family = "normal", mean = 0.005, sd = .005/.690)
# Medial Study 3: high risk vs. algorithm
data_model <- likelihood(family = "normal", mean = 0.015, sd = .015/2.133)
# Medial Study 3: high risk vs. medical records
data_model <- likelihood(family = "normal", mean = 0.007, sd = .007/0.947)
# Medial Study 3: medical records vs. algorithm
data_model <- likelihood(family = "normal", mean = 0.008, sd = .008/1.183)

# Medial Study 1: among top 4-10%, top 10% vs. high risk
data_model <- likelihood(family = "normal", mean = 0.009, sd = .009/1.337)
# Medial Study 1: top 3% vs. top 10%
data_model <- likelihood(family = "normal", mean = 0.008, sd = .008/1.035)
# Medial Study 2: high risk vs. active control
data_model <- likelihood(family = "normal", mean = 0.011, sd = .011/1.929)
# Medial Study 2: high risk reasons vs. high risk no reasons
data_model <- likelihood(family = "normal", mean = 0.007, sd = .007/1.174)
# Medial Study 2: high risk 1 reason vs. high risk 3 reasons
data_model <- likelihood(family = "normal", mean = 0.017, sd = .017/1.663)
# Medial Study 2: high risk X reasons interaction
data_model <- likelihood(family = "normal", mean = 0.020, sd = .020/1.399)
# Medial Study 2: among top 3%, high risk vs. top 3%
data_model <- likelihood(family = "normal", mean = 0.002, sd = .002/0.172)
# NEW Medial Study 2: among top 3%, high risk vs. top 3% (1 model)
data_model <- likelihood(family = "normal", mean = 0.002, sd = .002/0.175)
# NEW Medial Study 2: interaction of top 3% vs. 10%, high risk vs. top X%
data_model <- likelihood(family = "normal", mean = 0.019, sd = .019/1.488)

# Medial Study 4: portal+SMS vs. passive control
data_model <- likelihood(family = "normal", mean = 0.015, sd = .015/1.915)

# Example of significant p<.05 model...  Evidence inconclusive.
data_model <- likelihood(family = "normal", mean = 0.017, sd = .017/2.085)

# p5 - extended data Fig 1
data_model <- likelihood(family = "normal", mean = 0.009, sd = .009/1.337)
# p12 OLS regression w/ only top16-20% of risk
data_model <- likelihood(family = "normal", mean = 0.007, sd = .007/0.824)
#NEW p12 OLS regression w/ only top16-20% of risk (1 model)
data_model <- likelihood(family = "normal", mean = 0.007, sd = .007/0.815)
#NEW p12 OLS regression w/ only top11-15% of risk (1 model)
data_model <- likelihood(family = "normal", mean = 0.015, sd = .015/1.270)


#### STEP 2: GENERATE BF (run this whole section)
# specify priors
alt_prior <- prior(family = "cauchy", location = 0.000, scale = 0.1, range = c(-1, 1))
null_prior <- prior(family = "point", point = 0)
# weight likelihood by prior
m1 <- data_model * alt_prior
m0 <- data_model * null_prior
# take the intergal of each weighted likelihood 
# and divide them
bf <- integral(m1) / integral(m0)
# get a verbal description of the Bayes factor
summary(bf)
1/bf
