
#info here:
#https://rpubs.com/mclaire19/ggplot2-custom-themes

theme_medial <- function(){ 
    

    theme_classic() %+replace%    #replace elements we want to change
        
        theme(
          
          text = element_text(size = 7, color = "black"),
          
          axis.title = element_text(size = 7, color = "black"),              
            
          axis.text = element_text(size = 7, color = "grey30"),
            
          legend.text = element_text(size = 6, color = "black"),
          
          axis.line = element_line(linewidth = .3),
            
          axis.ticks = element_line(linewidth = .3)
            
        )
}

