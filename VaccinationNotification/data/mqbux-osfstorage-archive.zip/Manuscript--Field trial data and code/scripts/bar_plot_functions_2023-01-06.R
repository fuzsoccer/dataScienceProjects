

#Gail Rosenbaum
#2023-01-06
#this file contains functions that automatically make tables with proportions by 
#experimental condition and formatted bar graphs of data in the proportion tables


library(tidyverse)
#library(gridExtra)
#library(grid)
#library(ggtext)



sep <- function(p,n) {
  prop_mult <- p * (1 - p)
  sqrt( prop_mult / n)
}

#function for standard error of the mean 
sem <- function(x){
  sd(na.omit(x))/sqrt(length(na.omit(x)))
}

#make proportions and other helpful things
make_proportions <- function(df,outcome,condition,ndecimals = 2, comma = TRUE) {

  df2 <- data.frame(outcome = df[[outcome]],condition = df[[condition]])
  
  props <- aggregate(df2["outcome"],by=list(condition=df2[,"condition"]),
                     FUN = function(x) sum(x==1))
  props$total <- aggregate(df2["outcome"],by=list(cond=df2[,"condition"]),
                           FUN = length)[,"outcome"]
  props$prop <- props[,"outcome"]/props[,"total"]
  props$se <- sep(props$prop,props$total)
  props$ci <- props$se * 1.96
  props$perc <- props$prop * 100
  props$perc_se <- props$se * 100
  props$perc_ci <- props$ci * 100
  #make labels that include sample size
  if (comma == TRUE) {
  props$labs <- paste0(props$condition,
                       "\n(N = ", 
                       prettyNum(props$total,big.mark = ",", 
                                 scientific = FALSE),")")
  } else {
  props$labs <- paste0(props$condition,
                       "\n(N = ", props$total,")")
  }
  #the next 2 lines will put the labels in order within the DF, which is the factor order of the condition variables. may need to change this
  props$order <- 1:nrow(props) 
  
  props$labs <- factor(props$labs, 
                       levels = props$labs[
                         order(props$order)])
  
  #make a percentage with the percent sign for a bar plot label
  props$percentage <- paste0(format(round(props$perc,ndecimals), 
                                    trim=T, nsmall=1),"%")
  return(props)
}


#this function takes an output from make_proportions and plots it
bar_graph <- function(vacc_props, errorbars = "ci", plottitle, ylabel, 
                      include_count_label = FALSE, include_bar_label = TRUE,
                      accentcolors = TRUE, fontsz = 12, labelsz = 3,
                      rescale = TRUE, lims = c(NA, NA), breaks, vjust = 4,
                      setcolors, include_count_x = TRUE, include_caption = TRUE){

  if (!missing(setcolors)){
    colors <- setcolors
  } else if (accentcolors == TRUE) {
    colors <- c("grey",rep("#0093D5", nrow(vacc_props)-1))
  } else if (accentcolors == FALSE){
    colors <- c(rep("#0093D5", nrow(vacc_props)))
  }
  
  caption <- element_blank()
  
  #compute limits for error bars
  if (errorbars == "se"){
    
    #caption <- "Error bars represent standard errors"
    vacc_props$errors_neg <- vacc_props$perc-vacc_props$perc_se
    vacc_props$errors_pos <- vacc_props$perc+vacc_props$perc_se
    
    if (include_caption == TRUE) {
      caption <- "Error bars represent standard errors"
    }
    
  } else if (errorbars == "ci"){
    
    #caption <- "Error bars represent 95% confidence intervals"
    vacc_props$errors_neg <- vacc_props$perc-vacc_props$perc_ci
    vacc_props$errors_pos <- vacc_props$perc+vacc_props$perc_ci
    
    if (include_caption == TRUE) {
      caption <- "Error bars represent 95% confidence intervals"
    }
    
   } else {
    print("error - invalid entry for errorbars")
  }
  
   
  #if the raw numbers are large then cut the y-axis shorter and if we want the axis to be rescaled
  #also ignoring this statement if there are limits entered in function inputs
  if (max(vacc_props$errors_pos > 15) & rescale == TRUE & is.na(lims[1])){ 
    
  #determine axis limits - round up or down to the nearest multiple of 5
  lims <- c(plyr::round_any(min(vacc_props$errors_neg), 5, f = floor),
            plyr::round_any(max(vacc_props$errors_pos), 5, f = ceiling))

  }
  
  #determine the tic marks
  if (missing(breaks) & !is.na(lims[1])){
    
  breaks <- seq(lims[1],lims[2], by = 5)
  
  }
  
  if (include_count_x == TRUE){
    
    vacc_props$labs_use <- vacc_props$labs
    
  } else {
    
    vacc_props$labs_use <- vacc_props$condition

  }
  
  
  if (include_count_label == TRUE){
    
    vacc_props$bar_label <- paste0(vacc_props$percentage, "\n (", 
                                   vacc_props$outcome,"/\n",vacc_props$total,")")
    
  } else {
    
    vacc_props$bar_label <- vacc_props$percentage
    
  }
  
  
  
  plot <- ggplot(vacc_props, aes(x = labs_use, y=perc, fill=labs_use),2) +
    geom_bar(position="dodge", stat = "identity") +
    geom_errorbar(aes(ymin=errors_neg, ymax=errors_pos),
                  width=.2, position=position_dodge(.9)) +
    labs(x = "", y = "", caption = caption) + 
    theme_classic() + 
    theme(axis.text.x=element_text(size=fontsz),
          axis.text.y=element_text(size=fontsz),
          axis.title.y=element_text(size=fontsz, color = "grey30"),
          legend.position = "") +
    scale_fill_manual(values = colors) 
  
  
  if (include_bar_label == TRUE){
    plot <- plot +
    geom_text(aes(label=bar_label),colour="white", 
              position=position_dodge(width=0.9), vjust=vjust, size = labelsz) 
  }

  
  if (!is.na(lims[1])){
    plot <- plot + 
      coord_cartesian(ylim=lims) +
      scale_y_continuous(expand=c(0,0), breaks = breaks)
  }
  
  if (!missing(plottitle)){
    plot <- plot + ggtitle(plottitle)
  }
  
  if (!missing(ylabel)){
    plot <- plot + ylab(ylabel)
  }
  

  return(plot)
  
}















#make proportions and other helpful things
make_proportions_group <- function(df,outcome,condition_x,condition_col,ndecimals = 2,comma = TRUE, reorder = TRUE) {
  #for some reason this wasn't working for some input data. I suspect it has to 
  #do with data formatting. here, i'm reformatting the data to something that 
  #should work for the rest of the
  df2 <- data.frame(outcome = df[[outcome]],condition_x = df[[condition_x]],condition_col = df[[condition_col]])
  
  props <- aggregate(df2["outcome"],by=list(condition_x=df2[,"condition_x"],condition_col=df2[,"condition_col"]),
                     FUN = function(x) sum(x==1))
  props$total <- aggregate(df2["outcome"],by=list(condition_x=df2[,"condition_x"],condition_col=df2[,"condition_col"]),
                           FUN = length)[,"outcome"]
  props$prop <- props[,"outcome"]/props[,"total"]
  props$se <- sep(props$prop,props$total)
  props$ci <- props$se * 1.96
  props$perc <- props$prop * 100
  props$perc_se <- props$se * 100
  props$perc_ci <- props$ci * 100
  #make labels that include sample size
  if (comma == TRUE) {
    props$labs <- paste0(props$condition_x,
                         "\n(N = ", 
                         prettyNum(props$total,big.mark = ",", 
                                   scientific = FALSE),")")
  } else {
    props$labs <- paste0(props$condition_x,
                         "\n(N = ", props$total,")")
  }
  #the next 2 lines will put the labels in order within the DF, which is the factor order of the condition variables. may need to change this
  props$order <- 1:nrow(props) 
  
  if (reorder == TRUE) {
    
    props$labs <- factor(props$labs, 
                         levels = props$labs[
                           order(props$order)])
    
  }
  
  #make a percentage with the percent sign for a bar plot label
  props$percentage <- paste0(format(round(props$perc,ndecimals), 
                                    trim=T, nsmall=1),"%")
  return(props)
}


#this function takes an output from make_proportions and plots it
bar_graph_groups <- function(
    vacc_props, errorbars = "ci", plottitle, ylabel, xlabel, legend_label,
    include_count_label = FALSE, include_bar_label = TRUE, accentcolors = TRUE,
    rescale = TRUE, lims = c(NA, NA), breaks, vjust = 4,fontsz = 12, labelsz = 3, 
    setcolors, include_count_x = TRUE, include_caption = TRUE){
  
  if (!missing(setcolors)){
    colors <- setcolors
  } else if (accentcolors == TRUE) {
    colors <- c("grey",rep("#0093D5", nrow(vacc_props)-1))
  } else if (accentcolors == FALSE){
    colors <- c(rep("#0093D5", nrow(vacc_props)))
  }
  
  caption <- element_blank()
  
  #compute limits for error bars
  if (errorbars == "se"){
    
    #caption <- "Error bars represent standard errors"
    vacc_props$errors_neg <- vacc_props$perc-vacc_props$perc_se
    vacc_props$errors_pos <- vacc_props$perc+vacc_props$perc_se
    
    if (include_caption == TRUE) {
      caption <- "Error bars represent standard errors"
    }
    
  } else if (errorbars == "ci"){
    
    #caption <- "Error bars represent 95% confidence intervals"
    vacc_props$errors_neg <- vacc_props$perc-vacc_props$perc_ci
    vacc_props$errors_pos <- vacc_props$perc+vacc_props$perc_ci
    
    if (include_caption == TRUE) {
      caption <- "Error bars represent 95% confidence intervals"
    }
    
  } else {
    print("error - invalid entry for errorbars")
  }
  
  
  #if the raw numbers are large then cut the y-axis shorter and if we want the axis to be rescaled
  #also ignoring this statement if there are limits entered in function inputs
  if (max(vacc_props$errors_pos > 15) & rescale == TRUE & is.na(lims[1])){ 
    
    #determine axis limits - round up or down to the nearest multiple of 5
    lims <- c(plyr::round_any(min(vacc_props$errors_neg), 5, f = floor),
              plyr::round_any(max(vacc_props$errors_pos), 5, f = ceiling))
    
  }
  
  #determine the tic marks
  if (missing(breaks) & !is.na(lims[1])){
    
    breaks <- seq(lims[1],lims[2], by = 5)
    
  }
  
  if (include_count_x == TRUE){
    
    vacc_props$labs_use <- vacc_props$labs
    
  } else {
    
    vacc_props$labs_use <- vacc_props$condition_x
    
  }
  
  
  if (include_count_label == TRUE){
    
    vacc_props$bar_label <- paste0(vacc_props$percentage, "\n (", 
                                   vacc_props$outcome,"/\n",vacc_props$total,")")
    
  } else {
    
    vacc_props$bar_label <- vacc_props$percentage
    
  }
  
  
  
  plot <- ggplot(vacc_props, aes(x = condition_x, y=perc, fill=condition_col),2) +
    geom_bar(position="dodge", stat = "identity") +
    geom_errorbar(aes(ymin=errors_neg, ymax=errors_pos),
                  width=.2, position=position_dodge(.9)) +
    labs(x = "", y = "", caption = caption) + 
    theme_classic() + 
    theme(axis.text.x=element_text(size=fontsz),
          axis.text.y=element_text(size=fontsz),
          axis.title.y=element_text(size=fontsz,color = "grey30")) +
    scale_fill_manual(values = colors) 
  
  
  if (include_bar_label == TRUE){
    
  plot <- plot +
    geom_text(aes(label=bar_label),colour="white", 
              position=position_dodge(width=0.9), vjust=vjust, size = labelsz) 
  
  }
  
  
  if (!is.na(lims[1])){
    plot <- plot + 
      coord_cartesian(ylim=lims) +
      scale_y_continuous(expand=c(0,0), breaks = breaks)
  }
  
  if (!missing(plottitle)){
    plot <- plot + ggtitle(plottitle)
  }
  
  if (!missing(ylabel)){
    plot <- plot + ylab(ylabel)
  }
  
  if (!missing(xlabel)){
    plot <- plot + xlab(xlabel)
  }
  
  
  if (!missing(legend_label)){
    plot <- plot + labs(fill = legend_label)
  }
  
  return(plot)
  
}




















